# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: e8fa1d2bc8a64ddc820cc9802d59e252
- Android key alias: QGFzaHVuZ2FmYWMvUmVtaW5pc2Nl
- Android key password: df2012d67df5496dacac1a202cac25c8
      