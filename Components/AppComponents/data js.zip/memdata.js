export default [
    {
        id: '1',
        questions: 'How often did you use the telephone?\nWho did you call?\n',
        title:'Bakelite telephone',
        image: require('../../assets/images/memories/telephone.jpg')
    },
    {
        id: '2',
        questions: '',
        title: 'Bush Radio',
        image: require('../../assets/images/local_walks.jpg')
    },
    {
        id: '3',
        questions: '',
        title: 'Butlins Holiday Camp',
        image: require('../../assets/images/face_to_face.jpg')
    },
    {
        id: '4',
        questions: '',
        title: 'Cary Grant',
        image: require('../../assets/images/digital_inclusion.jpg')
    },
    {
        id: '5',
        questions: '',
        title:'Christmas Tree',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '6',
        questions: '',
        title:'Clothes Line',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '7',
        questions: '',
        title:'Coffee Maker',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '8',
        questions: '',
        title:'Cook Book',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '9',
        questions: '',
        title:'Corset',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '10',
        questions: '',
        title:'Elizabeth Taylor',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '11',
        questions: '',
        title:'Elvis Presley',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '12',
        questions: '',
        title:'Family Life',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '13',
        questions: '',
        title:'First Birth',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '14',
        questions: '',
        title:'Hats',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '15',
        questions: '',
        title:'Marilyn Monroe',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '16',
        questions: '',
        title:'Morris Manor',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '17',
        questions: '',
        title:'Phoenix Metro Cooker',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '18',
        questions: '',
        title:'Queens Coronation',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '19',
        questions: '',
        title:'Singer Sewing Machine',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '20',
        questions: '',
        title:'Sunday Night at the Palladuim',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '21',
        questions: '',
        title:'Swinging 60\'s',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '22',
        questions: '',
        title:'The Beatles',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '23',
        questions: '',
        title:'The way to a man\'s heart cookbok',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '24',
        questions: '',
        title:'Weding day',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '25',
        questions: '',
        title:'What\s my line?',
        image: require('../../assets/images/logo.png')
    },
    {
        id: '26',
        questions: '',
        title:'The Blue Lamp',
        image: require('../../assets/images/logo.png')
    },
]